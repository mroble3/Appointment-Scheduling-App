Title: Scheduler System for Appointments

Purpose: Created an application that would meet the outlined requirements. The application gives a natural experience to a user wanting to locate/control appointments.

Author: Mohamed Roble
Contact: mrobl30@wgu.edu
Application Version: 1.0.0
Date: 10/07/2022

IDE: Intellij IDEA Community 2022.2.1
JavaFX: JavaFX-SDK-17.0.4
MySQL Connector: mysql-connector-java-8.0.25
JDK: Java SE 17.0.4

How to start the program:
Extract the ZIP file if not done already.
Then continue to open the project in Intellij IDEA IDE
Click the green Run button on the upper right corner of the page
To Login - The user can use "test" for username and "test" for password if they do not have an account.

The report "additional" that was created to locate all appointments that users and contacts have.
Which is useful in instances where you need to locate what user "customer" is with what contact.