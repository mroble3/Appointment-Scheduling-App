//package controller;
//
//import database.DBAppointment;
//import database.DBContact;
//import database.DBCustomer;
//import database.DBUser;
//import javafx.collections.ObservableList;
//import javafx.fxml.FXML;
//import javafx.fxml.FXMLLoader;
//import javafx.scene.Scene;
//import javafx.scene.control.*;
//import javafx.stage.Stage;
//import model.Appointment;
//import model.Contact;
//
//import java.io.IOException;
//import java.time.LocalTime;
//
//
//import util.GeneralFunctions;
//import javafx.collections.FXCollections;
//import javafx.scene.Node;
//import javafx.scene.Parent;
//import javafx.scene.control.cell.PropertyValueFactory;
//import javafx.scene.layout.AnchorPane;
//
//import java.sql.SQLException;
//import java.time.LocalDate;
//import java.time.format.DateTimeFormatter;
//import java.util.Objects;
//
///**
// * Scheduler Controller class declaration.
// */
//public class SchedulerController {
//    public Button MainModifyAppointmentBtn;
//    public ComboBox MainTypeComboReport1;
//    private Stage stage;
//
//
//    @FXML
//    private AnchorPane MainScenePane;
//
//    @FXML
//    private javafx.scene.control.TableColumn<Appointment, Integer> MainAppointmentIDCol;
//
//    @FXML
//    private TableView<Appointment> MainAppointmentTable;
//
//    @FXML
//    private TextField MainAppointmentId;
//
//    @FXML
//    private javafx.scene.control.TableColumn<Contact, String> MainContactCol;
//
//    @FXML
//    private ComboBox<String> MainContactNameCombo;
//
//    @FXML
//    private javafx.scene.control.TableColumn<Appointment, Integer> MainCustomerIdCol;
//
//    @FXML
//    private ComboBox<Integer> MainCustomerIdCombo;
//
//
//    @FXML
//    private TextArea MainDescription;
//
//    @FXML
//    private javafx.scene.control.TableColumn<Appointment, String> MainDescriptionCol;
//
//    @FXML
//    private javafx.scene.control.TableColumn<Appointment, LocalTime> MainEndTimeCol;
//
//    @FXML
//    private ComboBox<LocalTime> MainEndTimeCombo;
//
//    @FXML
//    private TextField MainLocation;
//
//    @FXML
//    private javafx.scene.control.TableColumn<Appointment, String> MainLocationCol;
//
//
//    @FXML
//    private ComboBox<String> MainMonthComboReport;
//
//    @FXML
//    private TextField MainReportOneMatchingField;
//
//    @FXML
//    private TextField MainReportTwoMatchingField;
//
//    @FXML
//    private ComboBox<Integer> MainReportTwoUserIdCombo;
//
//    @FXML
//    private javafx.scene.control.TableColumn<Appointment, LocalTime> MainStartTimeCol;
//
//    @FXML
//    private ComboBox<LocalTime> MainStartTimeCombo;
//
//    @FXML
//    private TextField MainTitle;
//
//    @FXML
//    private javafx.scene.control.TableColumn<Appointment, String> MainTitleCol;
//
//    @FXML
//    private javafx.scene.control.TableColumn<Appointment, String> MainTypeCol;
//
//    @FXML
//    private ComboBox<String> MainTypeCombo;
//
//    @FXML
//    private ComboBox<String> MainTypeComboReport;
//
//    @FXML
//    private TableColumn<Appointment, Integer> MainUserIdCol;
//
//    @FXML
//    private ComboBox<Integer> MainUserIdCombo;
//
//    @FXML
//    private RadioButton MainViewAllRadioBtn;
//
//
//    @FXML
//    private RadioButton MainViewMonthRadioBtn;
//
//    @FXML
//    private RadioButton MainViewWeekRadioBtn;
//
//    @FXML
//    private DatePicker MainDatePicker;
//
//    /**
//     * Radio selection - Defines which function to call to populate table view depending on radio button selection.
//     */
//    @FXML
//    void RadioSelection() {
//        if (MainViewWeekRadioBtn.isSelected()) {
//
//            MainAppointmentTable.setItems(weeklist);
//            System.out.println("week selected");
//        } else if (MainViewMonthRadioBtn.isSelected()) {
//
//            MainAppointmentTable.setItems(monthlist);
//            System.out.println("month selected");
//        } else if (MainViewAllRadioBtn.isSelected()) {
//
//            MainAppointmentTable.setItems(DBAppointment.apptoblist);
//            System.out.println("All selected");
//        }
//    }
//
//    public void populate(Appointment a) {
//
//    }
//
//    ObservableList<String> TypeComboList = FXCollections.observableArrayList(
//            "Session Plan",
//            "Interrogate",
//            "Mention Time",
//            "Meeting End"
//    );
//    ObservableList<String> ListOfMonths = FXCollections.observableArrayList();
//    ObservableList<LocalTime> PossibleStartTimesList = FXCollections.observableArrayList(GeneralFunctions.getStartTimes());
//    ObservableList<LocalTime> PossibleEndTimesList = FXCollections.observableArrayList(GeneralFunctions.getStartTimes());
//    ObservableList<Appointment> weeklist = FXCollections.observableArrayList();
//    ObservableList<Appointment> monthlist = FXCollections.observableArrayList();
//
//
//    /**
//     * Initialize method.
//     *
//     * Lambda function for listener to populate fields to the left of tableview based on what user selects.
//     * @throws SQLException sql exception.
//     */
//    public void initialize() throws SQLException {
//
//        MainAppointmentTable.getItems().clear();
//        DBAppointment.apptoblist.clear();
//        DBAppointment.pullAppointments();
//        MainAppointmentTable.setItems(DBAppointment.apptoblist);
//        MainAppointmentIDCol.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
//        MainTitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
//        MainLocationCol.setCellValueFactory(new PropertyValueFactory<>("location"));
//        MainContactCol.setCellValueFactory(new PropertyValueFactory<>("contactId"));
//        MainTypeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
//        MainStartTimeCol.setCellValueFactory(new PropertyValueFactory<>("start"));
//        MainEndTimeCol.setCellValueFactory(new PropertyValueFactory<>("end"));
//        MainCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("customerId"));
//        MainUserIdCol.setCellValueFactory(new PropertyValueFactory<>("userID"));
//        MainDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
//
//        DBContact.contactNameList.clear();
//        DBContact.getContactNameList();
//        MainContactNameCombo.setItems(DBContact.contactNameList);
//
//        MainTypeCombo.setItems(TypeComboList);
//        MainTypeComboReport.setItems(TypeComboList);
//        MainTypeComboReport1.setItems(TypeComboList);
//        MainStartTimeCombo.setItems(PossibleStartTimesList);
//        MainEndTimeCombo.setItems(PossibleEndTimesList);
//
//        DBCustomer.customerIDist.clear();
//        DBCustomer.getCustomerIdList();
//        MainCustomerIdCombo.setItems(DBCustomer.customerIDist);
//
//        DBUser.userIDist.clear();
//        DBUser.getUserIdList();
//        MainUserIdCombo.setItems(DBUser.userIDist);
//        MainReportTwoUserIdCombo.getItems().clear();
//        MainReportTwoUserIdCombo.setItems(DBUser.userIDist);
//
//
//
//        MainAppointmentTable.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) ->
//        {
//            if (newVal != null) {
//                MainAppointmentId.setText(String.valueOf(newVal.getAppointmentId()));
//                MainAppointmentId.setFocusTraversable(false);
//                MainTitle.setText(newVal.getTitle());
//                MainLocation.setText(newVal.getLocation());
//                MainTypeCombo.valueProperty().setValue(newVal.getType());
//                MainDatePicker.valueProperty().setValue(GeneralFunctions.datePickerFromSelection(newVal.getStart()));
//                MainStartTimeCombo.valueProperty().setValue(GeneralFunctions.timeFromSelection(newVal.getStart()));
//                MainEndTimeCombo.valueProperty().setValue(GeneralFunctions.timeFromSelection(newVal.getEnd()));
//                MainCustomerIdCombo.valueProperty().setValue(newVal.getCustomerId());
//                MainUserIdCombo.valueProperty().set(newVal.getUserID());
//                MainDescription.setText(newVal.getDescription());
//                try {
//                    MainContactNameCombo.valueProperty().setValue(DBContact.getContactName(newVal.getContactId()));
//                } catch (SQLException e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//
//        for (Appointment appt : DBAppointment.apptoblist) {
//            DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd kk:mm");
//            LocalDate ld = LocalDate.parse(appt.getStart(), df);
//            ListOfMonths.add(String.valueOf(ld.getMonth()));
//            if (GeneralFunctions.checkMonth(appt.getStart())) {
//                monthlist.add(appt);
//                if (GeneralFunctions.checkWeek(appt.getStart())) {
//                    weeklist.add(appt);
//                }
//            }
//        }
//
//        MainMonthComboReport.setItems(ListOfMonths);
//    }
//
//    /**
//     * Opens Contact Schedule form.
//     * @throws IOException i/o exception
//     * @param event once button selected the contact schedule form is loaded.
//     */
//    public void MainOpenContactSchedule(javafx.event.ActionEvent event) throws IOException {
//        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../View/ContactSchedule.fxml")));
//        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
//        Scene contactSchedule = new Scene(root);
//        stage.setScene(contactSchedule);
//        stage.show();
//    }
//    /**
//     * Opens the Customer form.
//     * @param event once button selected the customer schedule form is loaded.
//     * @throws IOException i/o exception
//     */
//    public void MainOpenCustomer(javafx.event.ActionEvent event) throws IOException {
//        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../View/CustomerForm.fxml")));
//        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
//        Scene contactSchedule = new Scene(root);
//        stage.setScene(contactSchedule);
//        stage.show();
//    }
//
//    /**
//     * Exit Application function. - Which closes the application scne.
//     */
//    public void exitApplication() {
//        stage = (Stage) MainScenePane.getScene().getWindow();
//        stage.close();
//    }
//
//    /**
//     * Once save button is selected the Save function is executed.
//     * The function creates an object of the appointment to add, assigning values from the collected Fields.
//     * It calls general functions from the utilities package, to ensure input data is validated. It will then call
//     * upon the DB package functions to save the appointment to the database after validation is performed, or else
//     * it will throw error messages as exceptions are came across.
//     */
//    public void SaveBtnPress() {
//        try {
//            LocalDate date = MainDatePicker.getValue();
//            LocalTime startTime = MainStartTimeCombo.getValue();
//            LocalTime endTime = MainEndTimeCombo.getValue();
//            String contactName = MainContactNameCombo.getValue();
//
//            Appointment apptToAdd = new Appointment();
//            apptToAdd.setTitle(MainTitle.getText());
//            apptToAdd.setLocation(MainLocation.getText());
//            apptToAdd.setDescription(MainDescription.getText());
//            apptToAdd.setType(MainTypeCombo.getValue());
//            apptToAdd.setStart(GeneralFunctions.UserTimeToUTC(date, startTime));
//            apptToAdd.setEnd(GeneralFunctions.UserTimeToUTC(date, endTime));
//            apptToAdd.setContactId(DBContact.getContactId(contactName));
//            apptToAdd.setCustomerId(MainCustomerIdCombo.getValue());
//            apptToAdd.setUserID(MainUserIdCombo.getValue());
//
//            if (endTime.isAfter(startTime)) {
//                if (Objects.equals(MainAppointmentId.getText(), "Auto-Generated")) {
//                    if (((GeneralFunctions.DoesOverlap(startTime, endTime, date, apptToAdd.getCustomerId(), -1)) == -1)){
//
//                        int rowsAffected = DBAppointment.addNewAppt(apptToAdd);
//
//                        if (rowsAffected > 0) {
//                            GeneralFunctions.successMessage("Appointment Added", "The appointment has been successfully added");
//                            MainAppointmentTable.getItems().clear();
//                            DBAppointment.pullAppointments();
//                            MainAppointmentTable.setItems(DBAppointment.apptoblist);
//
//                        } else {
//                            GeneralFunctions.alertError("Failed", "Appointment not added, check fields for errors");
//                        }
//                    } else {
//                        GeneralFunctions.alertError("Appointment Time Conflict", "Selected Appointment times overlap with appointment: " +
//                                (GeneralFunctions.DoesOverlap(startTime, endTime, date, apptToAdd.getCustomerId(), apptToAdd.getAppointmentId())));
//                    }
//                } else {
//                    apptToAdd.setAppointmentId(Integer.parseInt(MainAppointmentId.getText()));
//                    if (((GeneralFunctions.DoesOverlap(startTime, endTime, date, apptToAdd.getCustomerId(), apptToAdd.getAppointmentId())) == -1)){
//                        int rowsAffected = DBAppointment.updateAppt(apptToAdd);
//                        if (rowsAffected > 0) {
//                            GeneralFunctions.successMessage("Appointment Updated", "Appointment " + apptToAdd.getAppointmentId() + " was updated Successfully");
//                            MainAppointmentTable.getItems().clear();
//                            DBAppointment.pullAppointments();
//                            MainAppointmentTable.setItems(DBAppointment.apptoblist);
//                        }
//                    } else {
//                        GeneralFunctions.alertError("Appointment Time Conflict", "Selected Appointment times overlap with appointment: " +
//                                (GeneralFunctions.DoesOverlap(startTime, endTime, date, apptToAdd.getCustomerId(), apptToAdd.getAppointmentId())));
//                    }
//                }
//
//            } else {
//                GeneralFunctions.alertError("End time before start time", "Please ensure the appointment end time is at least 15min after the start time");
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        } catch (NullPointerException e){
//            GeneralFunctions.alertError("Fields are empty", "Please ensure all fields have content");
//        } catch (NumberFormatException e){
//            e.printStackTrace();
//            GeneralFunctions.alertError("Please click 'Add New Appointment' button", "User must generate new appointment ID by clicking the 'Add New Appointment' button before trying to save the appointment");
//        }
//    }
//
//    /**
//     * addNewAppointment - clears the data in text fields to allow user to enter new values for an appointment.
//     */
//    public void addNewAppointment() {
//        MainAppointmentTable.getSelectionModel().clearSelection();
//        MainAppointmentId.setText("Auto-Generated");
//        MainTitle.clear();
//        MainLocation.clear();
//        MainDescription.clear();
//        MainTypeCombo.valueProperty().set(null);
//        MainDatePicker.valueProperty().set(null);
//        MainStartTimeCombo.valueProperty().set(null);
//        MainEndTimeCombo.valueProperty().set(null);
//        MainCustomerIdCombo.valueProperty().set(null);
//        ;
//        MainUserIdCombo.valueProperty().set(null);
//        ;
//        MainContactNameCombo.valueProperty().set(null);
//        ;
//    }
//
//    /**
//     * @throws SQLException SQL exception if there is problem with .
//     * DeleteAppointment() - provides validation that an appointment to delete exists by id.
//     * Then proceeds to throw an alert when successfully deleted..
//     */
//    public void DeleteAppointment() throws SQLException {
//        if ((MainAppointmentId.getText().equals("")) || MainAppointmentId.getText().equals("Auto-Generated")) {
//            GeneralFunctions.alertError("No appointment selected", "Please select appointment from table to delete");
//        } else {
//            Appointment apptToDelete = new Appointments();
//            apptToDelete.setAppointmentId(Integer.parseInt(MainAppointmentId.getText()));
//            int tempid = apptToDelete.getAppointmentId();
//            if (GeneralFunctions.confirmationMessage("Confirm Delete", "Appointment will be deleted",
//                    "Confirm you want to delete appointment with ID of " + tempid)) {
//                int rowsAffected = DBAppointment.deleteAppointment(tempid);
//                if (rowsAffected > 0) {
//                    GeneralFunctions.successMessage("Appointment Deleted", "Appointment " + tempid + " has been successfully deleted");
//                    MainAppointmentTable.getItems().clear();
//                    DBAppointment.pullAppointments();
//                    MainAppointmentTable.setItems(DBAppointment.apptoblist);
//                } else {
//                    GeneralFunctions.alertError("Failed", "Appointment was not deleted");
//                }
//            }
//        }
//    }
//
//    /**
//     * Get Results One - Gathers the user selections from combo box, looks through list of appointments for matches
//     * and returns those matches to text field.(for the first report generation handling.)
//     */
//    public void getResultsReport1(){
//        int count = 0;
//        DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd kk:mm");
//        String selectedmonth = MainMonthComboReport.getValue();
//        String selecttype = MainTypeComboReport.getValue();
//        for(Appointments appt: DBAppointment.apptoblist){
//            LocalDate ld = LocalDate.parse(appt.getStart(), df);
//            String month = String.valueOf(ld.getMonth());
//            if(selectedmonth.equals(month) && (selecttype.equals(appt.getType()))){
//                count ++;
//            }
//        }
//        MainReportOneMatchingField.setText(String.valueOf(count));
//    }
//    /**
//     * Get Results Two - Gathers the user selections from combo box, looks through list of appointments for matches
//     * and returns those matches to text field. (for the second report generation handling.)
//     */
//    public void getResultsReport2() {
//        int count = 0;
//        for (Appointments appt : DBAppointment.apptoblist) {
//            if ((MainReportTwoUserIdCombo.getValue() == appt.getUserID()) && (MainTypeComboReport1.getValue().equals(appt.getType()))) {
//                count++;
//            }
//        }
//        MainReportTwoMatchingField.setText(String.valueOf(count));
//    }
//}
//
//
//
//
//
